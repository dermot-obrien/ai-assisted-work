---
name: aaw-work-status
description: Report status for one or more AI-Assisted Work items in this repository. Use when asked for work item progress, activity state, or work summaries.
---

# AAW Work Status

1. Read and follow exactly:       `.ai-assisted-work/packages/skills/work-management/work-status.md`
2. Treat that file as the source of truth for workflow steps and constraints.
3. Keep all work scoped to this repository.
