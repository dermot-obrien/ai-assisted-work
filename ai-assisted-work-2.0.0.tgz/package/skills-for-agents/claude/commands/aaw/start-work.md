# /start-work

Create a new work item with scope, plan, and progress tracking.

## Instructions

**Read and follow exactly the full agent instructions at:**

`.ai-assisted-work/packages/skills/work-management/start-work.md`
